<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  // Get the user's input data
  $name = $_POST["name"];
  $email = $_POST["email"];
  $message = $_POST["contact_number"];
  // Add this line to get the room ID

  // TODO: Insert this data into your database to mark the room as reserved
  // Example code (please modify according to your database setup):
  $servername = "localhost";
  $username = "root";
  $password = "Kashikf101";
  $dbname = "my_database";

  // Create a connection
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Check the connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Insert data into the database
  $sql = "INSERT INTO reservations (name, email, contact_number) VALUES ('$name', '$email', '$contact_number')";

  if ($conn->query($sql) === TRUE) {
    // Reservation successful
    echo "Reservation successful!";
  } else {
    // Reservation failed
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

  // Close the database connection
  $conn->close();
}
?>
